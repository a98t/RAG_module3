https://github.com/a98t/RAG_module3.git

https://drive.google.com/file/d/1P5RD-Tz7r7SYuAcVyQul3963fjQqOdG1/view?usp=drive_link